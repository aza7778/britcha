// Vercel serverless funksiya: brauzer -> /api/chat -> Anthropic API
// API kalit faqat serverda (Environment Variable) saqlanadi.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Faqat POST so\'rov' });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: 'ANTHROPIC_API_KEY Vercelda sozlanmagan' });

  const body = req.body || {};
  const topic = String(body.topic || 'anything the student wants').slice(0, 80);
  let messages = Array.isArray(body.messages) ? body.messages : [];
  messages = messages
    .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map(m => ({ role: m.role, content: m.content.slice(0, 600) }))
    .slice(-14);
  if (!messages.length || messages[0].role !== 'user') return res.status(400).json({ error: 'Xabar noto\'g\'ri' });

  const system = `You are Emma, a friendly English speaking partner for a beginner (A1-A2) learner whose first language is Uzbek.
Topic: ${topic}.
Rules:
- Reply in very simple English, maximum 2 short sentences, and end with one easy question.
- If the learner made a grammar or word mistake, add a new line after your reply that starts with "💡" and gives the corrected sentence plus a one-sentence explanation in Uzbek.
- If the learner writes in Uzbek, gently encourage English and put the English version after "💡".
- Be warm and encouraging. No markdown, no lists.`;

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.CLAUDE_MODEL || 'claude-haiku-5-5', max_tokens: 300, system, messages })
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: (data.error && data.error.message) || 'AI xatolik berdi' });
    const reply = (data.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n').trim();
    return res.status(200).json({ reply });
  } catch (e) {
    return res.status(500).json({ error: 'Server xatoligi' });
  }
};
