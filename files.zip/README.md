# So'z Yodlash — Vercelga joylash

1. Arxivni oching, papkani GitHub'ga yuklang (yoki `vercel` CLI ishlating).
2. vercel.com → Add New → Project → shu repo'ni tanlang → Deploy.
3. Project → Settings → Environment Variables:
   - `ANTHROPIC_API_KEY` = kalitingiz (console.anthropic.com dan oling)
   - (ixtiyoriy) `CLAUDE_MODEL` = model nomi (standart: claude-haiku-5-5)
4. Deployments → Redeploy (o'zgaruvchi ishlashi uchun).

Eslatma: mikrofon (ovoz tanish) Chrome/Edge/Safari'da va faqat HTTPS'da ishlaydi — Vercel HTTPS beradi.
Fayl `index.html`ni to'g'ridan-to'g'ri ochsangiz AI suhbat ishlamaydi (server funksiya kerak).
